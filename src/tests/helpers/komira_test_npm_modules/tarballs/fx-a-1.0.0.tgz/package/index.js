module.exports = { name: 'fx-a', bVersion: require('fx-b').version };
